-- Cleber Matheus MobileApp Beta 1 Version 0.5.0.0 --
// Descri��o
	Nome: Cleber Matheus MobileApp Beta 1
	Vers�o: 0.5
	Licen�a: GNU Vers�o 3 - Software Livre
	Sistemas Compat�veis: Windows 7 com +IE10(recomendado)/Windows 8 Pro
	
// ChangeLog
	v0.5
		+ Adicionado a P�gina Principal
		+ Adicionado o Blogs
		+ Adicionado a Central de Aplicativos
		+ Adicionado o Cleber Matheus AppSeries
		+ Adicionado o Jogos
		+ Adicionado o Meus Projetos
		+ Adicionado o OpenSource
		+ Adicionado para os n�o lan�ados - "Em Breve!"
	v0.4.5
		* Atualizado o C�digo-Fonte
	v0.1
		- Adicionado a Tela Inicial
		- Adicionado o Bot�o para Fechar a Janela
	
// Contato
	Bugs ou erros favor enviar um email para:
	clebermatheus@outlook.com
	
// Licen�a
					 GNU GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.
