﻿function app(){
	delsec();
	document.getElementById('frame1').src='http://clebermatheus.users.sourceforge.net/app/findex.html';
	document.getElementById('frame1').style.display="block";
	document.getElementById("title").innerHTML="Centra de Aplicativos";
}
function blogs(){
	delsec();
	document.getElementById("title").innerHTML="Blogs";
	document.getElementById('frame1').style.display="none";
	document.getElementById('blogs1').style.display="block";
}
function delsec(){
	document.getElementById('blogs1').style.display='none';
	document.getElementById('editions1').style.display="none";
	document.getElementById('opensource1').style.display="none";
	document.getElementById('programacao1').style.display="none";
	document.getElementById('project1').style.display="none";
	document.getElementById('sobre1').style.display="none";
	document.getElementById('videos1').style.display="none";
	document.getElementById('webdesign1').style.display="none";
}
function editions(){
	delsec();
	document.getElementById("title").innerHTML="Cleber Matheus AppSeries";
	document.getElementById('frame1').style.display="none";
	document.getElementById('editions1').style.display="block";
}
function frame(){
	document.getElementByTagName('header').style.display='none';
	document.getElementById('lateral').style.display='none';
	document.getElementById('conteudo').style.width='100%';
}
function games(){
	delsec();
	document.getElementById('frame1').src='http://clebermatheus.users.sourceforge.net/games/findex.html';
	document.getElementById('frame1').style.display="block";
	document.getElementById("title").innerHTML="Jogos";
}
function home(){
	delsec();
	document.getElementById('frame1').style.display="block";
	document.getElementById("title").innerHTML="Cleber Matheus MobileApp Beta 3";
	document.getElementById('frame1').src='http://clebermatheus.users.sourceforge.net/fhome.html';
}
function opensource(){
	delsec();
	document.getElementById('frame1').style.display="none";
	document.getElementById('opensource1').style.display="block";
	document.getElementById("title").innerHTML="OpenSource";
}
function programacao(){
	delsec();
	document.getElementById('frame1').style.display="none";
	document.getElementById('programacao1').style.display="block";
	document.getElementById("title").innerHTML="Programação";
}
function projetos(){
	delsec();
	document.getElementById('frame1').style.display="none";
	document.getElementById('project1').style.display="block";
	document.getElementById("title").innerHTML="Meus Projetos";
}
function sobre(){
	delsec();
	document.getElementById('frame1').style.display="none";
	document.getElementById('sobre1').style.display="block";
	document.getElementById("title").innerHTML="Sobre";
}
function videos(){
	delsec();
	document.getElementById('frame1').style.display="none";
	document.getElementById('videos1').style.display="block";
	document.getElementById("title").innerHTML="Vídeos";
}
function webdesign(){
	delsec();
	document.getElementById('frame1').style.display="none";
	document.getElementById('webdesign1').style.display="block";
	document.getElementById("title").innerHTML="WebDesign";
}
